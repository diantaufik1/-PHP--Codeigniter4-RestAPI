<?php namespace Tests\Support\Database;

use CodeIgniter\Database\Query;

class MockQuery extends Query
{

}
