<?php
// seven wonders of the ancient world
return [
   'one' => 'Pyramid of Giza',
   'tre' => 'Colossus of Rhodes',
   'fiv' => 'Temple of Artemis',
   'sev' => 'Hanging Gardens of Babylon',
];
